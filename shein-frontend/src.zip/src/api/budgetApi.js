const BASE = "http://localhost/work/shein/backend/budget";

export const getBudgets = async (month_id) => {
  const res = await fetch(`${BASE}/getBudget.php?month_id=${month_id}`);
  return await res.json();
};

export const addBudget = async (month_id, value, description) => {
  const res = await fetch(`${BASE}/addBudget.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ month_id, value, description })
  });
  return await res.json();
};

export const updateBudget = async (id, value, description) => {
  const res = await fetch(`${BASE}/updateBudget.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, value, description })
  });
  return await res.json();
};

export const deleteBudget = async (id) => {
  const res = await fetch(`${BASE}/deleteBudget.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  return await res.json();
};
