const BASE = "http://localhost/work/shein/backend/customs";

export const getCustoms = async (month_id) => {
  const res = await fetch(`${BASE}/getCustoms.php?month_id=${month_id}`);
  return await res.json();
};

export const addCustom = async (month_id, customs_fee) => {
  const res = await fetch(`${BASE}/addCustom.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ month_id, customs_fee })
  });
  return await res.json();
};

export const updateCustom = async (id, customs_fee) => {
  const res = await fetch(`${BASE}/updateCustom.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, customs_fee })
  });
  return await res.json();
};

export const deleteCustom = async (id) => {
  const res = await fetch(`${BASE}/deleteCustom.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  return await res.json();
};
