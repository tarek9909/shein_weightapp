const BASE = "http://localhost/work/shein/backend/payments";

export const getPayments = async (month_id) => {
  const res = await fetch(`${BASE}/getPayments.php?month_id=${month_id}`);
  return await res.json();
};

export const addPayment = async (month_id, payment_amount) => {
  const res = await fetch(`${BASE}/addPayment.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ month_id, payment_amount })
  });
  return await res.json();
};

export const updatePayment = async (id, payment_amount) => {
  const res = await fetch(`${BASE}/updatePayment.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, payment_amount })
  });
  return await res.json();
};

export const deletePayment = async (id) => {
  const res = await fetch(`${BASE}/deletePayment.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  return await res.json();
};
