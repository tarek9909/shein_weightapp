const BASE="http://localhost/work/shein/backend/month";
export const getMonths=async()=>{const res=await fetch(`${BASE}/getMonths.php`);return await res.json()};
export const addMonth=async(name)=>{const res=await fetch(`${BASE}/addMonth.php`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})});return await res.json()};
export const updateMonth=async(id,name)=>{const res=await fetch(`${BASE}/updateMonth.php`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,name})});return await res.json()};
export const deleteMonth=async(id)=>{const res=await fetch(`${BASE}/deleteMonth.php?id=${id}`);return await res.json()};
