export const BASE="http://localhost/work/shein/backend/orders";

export const getOrders = async (month_id) => {
  const res = await fetch(`${BASE}/getOrders.php?month_id=${month_id}`);
  return await res.json();
};

export const addOrder = async (month_id, order_details) => {
  const res = await fetch(`${BASE}/addOrder.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ month_id, order_details })
  });
  return await res.json();
};

export const updateOrder = async (id, order_details) => {
  const res = await fetch(`${BASE}/updateOrder.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, order_details })
  });
  return await res.json();
};

export const deleteOrder = async (id) => {
  const res = await fetch(`${BASE}/deleteOrder.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id })
  });
  return await res.json();
};
