import { useState, useEffect } from "react";
import { getMonths, addMonth } from "../api/monthApi";
import { getOrders, addOrder, updateOrder, deleteOrder } from "../api/ordersApi";
import { getPayments, addPayment, updatePayment, deletePayment } from "../api/paymentsApi";
import { getCustoms, addCustom, updateCustom, deleteCustom } from "../api/customsApi";
import { getBudgets, addBudget, updateBudget, deleteBudget } from "../api/budgetApi";

export default function Dashboard() {
  const [months, setMonths] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(null);
  const [orders, setOrders] = useState([]);
  const [payments, setPayments] = useState([]);
  const [customs, setCustoms] = useState([]);
  const [budgets, setBudgets] = useState([]);
  const [newMonthName, setNewMonthName] = useState("");
  const [newOrder, setNewOrder] = useState("");
  const [newPayment, setNewPayment] = useState("");
  const [newCustom, setNewCustom] = useState("");
  const [newBudgetValue, setNewBudgetValue] = useState("");
  const [newBudgetDesc, setNewBudgetDesc] = useState("");

  useEffect(() => { fetchMonths(); }, []);
  useEffect(() => {
    if (selectedMonth) {
      fetchOrders(selectedMonth);
      fetchPayments(selectedMonth);
      fetchCustoms(selectedMonth);
      fetchBudgets(selectedMonth);
    }
  }, [selectedMonth]);

  const fetchMonths = async () => {
    const data = await getMonths();
    setMonths(data);
    if (data.length > 0) setSelectedMonth(data[0].id);
  };
  const fetchOrders = async (monthId) => setOrders(await getOrders(monthId));
  const fetchPayments = async (monthId) => setPayments(await getPayments(monthId));
  const fetchCustoms = async (monthId) => setCustoms(await getCustoms(monthId));
  const fetchBudgets = async (monthId) => setBudgets(await getBudgets(monthId));

  const handleAddMonth = async () => {
    if (!newMonthName) return;
    const res = await addMonth(newMonthName);
    if (res.success) { setMonths([...months, { id: res.id, name: newMonthName }]); setNewMonthName(""); }
  };
  const handleAddOrder = async () => {
    if (!newOrder || !selectedMonth) return;
    const res = await addOrder(selectedMonth, newOrder);
    if (res.success) { setOrders([...orders, { id: res.id, order_details: newOrder }]); setNewOrder(""); }
  };
  const handleAddPayment = async () => {
    if (!newPayment || !selectedMonth) return;
    const res = await addPayment(selectedMonth, newPayment);
    if (res.success) { setPayments([...payments, { id: res.id, payment_amount: newPayment }]); setNewPayment(""); }
  };
  const handleAddCustom = async () => {
    if (!newCustom || !selectedMonth) return;
    const res = await addCustom(selectedMonth, newCustom);
    if (res.success) { setCustoms([...customs, { id: res.id, customs_fee: newCustom }]); setNewCustom(""); }
  };
  const handleAddBudget = async () => {
    if (!newBudgetValue || !selectedMonth) return;
    const res = await addBudget(selectedMonth, newBudgetValue, newBudgetDesc);
    if (res.success) { 
      setBudgets([...budgets, { id: res.id, value: newBudgetValue, description: newBudgetDesc }]);
      setNewBudgetValue(""); 
      setNewBudgetDesc(""); 
    }
  };

  const handleUpdateOrder = async (id, value) => {
    const res = await updateOrder(id, value);
    if (res.success) setOrders(orders.map(o => o.id===id ? {...o, order_details:value} : o));
  };
  const handleUpdatePayment = async (id, value) => {
    const res = await updatePayment(id, value);
    if (res.success) setPayments(payments.map(p => p.id===id ? {...p, payment_amount:value} : p));
  };
  const handleUpdateCustom = async (id, value) => {
    const res = await updateCustom(id, value);
    if (res.success) setCustoms(customs.map(c => c.id===id ? {...c, customs_fee:value} : c));
  };
  const handleUpdateBudget = async (id, value, description) => {
    const res = await updateBudget(id, value, description);
    if (res.success) setBudgets(budgets.map(b => b.id===id ? {...b, value, description} : b));
  };

  const handleDeleteOrder = async (id) => {
    const res = await deleteOrder(id);
    if (res.success) setOrders(orders.filter(o => o.id!==id));
  };
  const handleDeletePayment = async (id) => {
    const res = await deletePayment(id);
    if (res.success) setPayments(payments.filter(p => p.id!==id));
  };
  const handleDeleteCustom = async (id) => {
    const res = await deleteCustom(id);
    if (res.success) setCustoms(customs.filter(c => c.id!==id));
  };
  const handleDeleteBudget = async (id) => {
    const res = await deleteBudget(id);
    if (res.success) setBudgets(budgets.filter(b => b.id!==id));
  };

  // Calculate remaining dynamically
  const remaining = () => {
    const totalOrders = orders.reduce((sum, o) => sum + Number(o.order_details), 0);
    const totalCustoms = customs.reduce((sum, c) => sum + Number(c.customs_fee), 0);
    const totalPayments = payments.reduce((sum, p) => sum + Number(p.payment_amount), 0);
    return totalOrders + totalCustoms - totalPayments;
  };
const actualCash = () => {
  const initialBudget = budgets.find(b => b.description.toLowerCase() === "initial");
  const initialValue = initialBudget ? Number(initialBudget.value) : 0;
  const totalOrders = orders.reduce((sum, o) => sum + Number(o.order_details), 0);
  const totalCustoms = customs.reduce((sum, c) => sum + Number(c.customs_fee), 0);
  const totalPayments = payments.reduce((sum, p) => sum + Number(p.payment_amount), 0);
  return initialValue + totalPayments - totalOrders - totalCustoms;
};
  return (
    <div>
      <h1>SHEIN Dashboard</h1>
      <div class="middle">
        <select class="select-wrapper" onChange={e => setSelectedMonth(Number(e.target.value))} value={selectedMonth || ""}>
          {months.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
        </select>
        <input value={newMonthName} onChange={e=>setNewMonthName(e.target.value)} placeholder="New Month"/>
        <button class="btn2" onClick={handleAddMonth}>Add Month</button>
      </div>

      {/* Budget Section */}
       <div className="container">
      <div className="budget-section column">
        <h2>Budgets</h2>
        <input type="number" value={newBudgetValue} onChange={e=>setNewBudgetValue(e.target.value)} placeholder="Value"/>
        <input value={newBudgetDesc} onChange={e=>setNewBudgetDesc(e.target.value)} placeholder="Description"/>
        <button onClick={handleAddBudget}>Add Budget</button>

        

        <ul>
          {budgets.map(b =>
            <li key={b.id}>
              <input type="number" value={b.value} onChange={e => setBudgets(
                budgets.map(bu => bu.id===b.id ? {...bu, value:e.target.value} : bu)
              )} 
              onBlur={e => handleUpdateBudget(b.id, e.target.value, b.description)}
              />
              <input value={b.description} onChange={e => setBudgets(
                budgets.map(bu => bu.id===b.id ? {...bu, description:e.target.value} : bu)
              )} 
              onBlur={e => handleUpdateBudget(b.id, b.value, e.target.value)}
              />
              <button onClick={()=>handleDeleteBudget(b.id)}>Delete</button>
            </li>
          )}
        </ul>
      </div>
      <div className="column">
 <h2><p>Remaining to acquire budget:</p> {remaining()}</h2>
 </div>
 <div className="column">
  <h2>Actual Cash:</h2>
  <h2>{actualCash()}</h2>
</div>

 </div>
      {/* Orders / Payments / Customs */}
      <div className="container">
        <div className="column">
          <h2>Orders</h2>
          <input value={newOrder} onChange={e=>setNewOrder(e.target.value)} placeholder="New Order"/>
          <button onClick={handleAddOrder}>Add</button>
          <ul>
            {orders.map(o =>
              <li key={o.id}>
                <input 
                  value={o.order_details} 
                  onChange={e => setOrders(orders.map(ord => ord.id===o.id ? {...ord, order_details:e.target.value} : ord))}
                  onBlur={e => handleUpdateOrder(o.id, e.target.value)}
                />
                <button onClick={()=>handleDeleteOrder(o.id)}>Delete</button>
              </li>
            )}
          </ul>
        </div>

        <div className="column">
          <h2>Payments</h2>
          <input value={newPayment} onChange={e=>setNewPayment(e.target.value)} placeholder="New Payment"/>
          <button onClick={handleAddPayment}>Add</button>
          <ul>
            {payments.map(p =>
              <li key={p.id}>
                <input 
                  value={p.payment_amount} 
                  onChange={e => setPayments(payments.map(pay => pay.id===p.id ? {...pay, payment_amount:e.target.value} : pay))}
                  onBlur={e => handleUpdatePayment(p.id, e.target.value)}
                />
                <button onClick={()=>handleDeletePayment(p.id)}>Delete</button>
              </li>
            )}
          </ul>
        </div>

        <div className="column">
          <h2>Customs</h2>
          <input value={newCustom} onChange={e=>setNewCustom(e.target.value)} placeholder="New Custom"/>
          <button onClick={handleAddCustom}>Add</button>
          <ul>
            {customs.map(c =>
              <li key={c.id}>
                <input 
                  value={c.customs_fee} 
                  onChange={e => setCustoms(customs.map(cu => cu.id===c.id ? {...cu, customs_fee:e.target.value} : cu))}
                  onBlur={e => handleUpdateCustom(c.id, e.target.value)}
                />
                <button onClick={()=>handleDeleteCustom(c.id)}>Delete</button>
              </li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
