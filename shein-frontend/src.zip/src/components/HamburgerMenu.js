import { useState } from "react";
import { Link } from "react-router-dom";
import "../HamburgerMenu.css";

export default function HamburgerMenu() {
  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen(!open);

  return (
    <>
      {/* Hamburger button */}
      <button className="hamburger-btn" onClick={toggleMenu}>☰</button>

      {/* Overlay popup */}
      <div className={`menu-overlay ${open ? "open" : ""}`} onClick={toggleMenu}>
        <div className="menu-content" onClick={e => e.stopPropagation()}>
        
          <nav className="menu-links">
            <Link to="/" onClick={toggleMenu}>Dashboard</Link>
            <Link to="/reports" onClick={toggleMenu}>Reports</Link>
            {/* Add more links here */}
          </nav>
        </div>
      </div>
    </>
  );
}
