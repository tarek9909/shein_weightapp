import React from "react";

export default function MonthSelector({ months, onSelect }) {
  return (
    <div className="month-selector">
      <label>Select Month:</label>
      <select onChange={(e) => onSelect(e.target.value)}>
        <option value="">-- Choose Month --</option>
        {months.map((m) => (
          <option key={m.id} value={m.id}>Month {m.id}</option>
        ))}
      </select>
    </div>
  );
}
